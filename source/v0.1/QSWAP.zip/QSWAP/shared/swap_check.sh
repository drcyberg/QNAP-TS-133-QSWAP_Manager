#!/bin/bash

SHORT_BEEP='/sbin/hal_app --se_buzzer enc_id=0,mode=101 - short beep'
LONG_BEEP='/sbin/hal_app --se_buzzer enc_id=0,mode=100 - long beep'
LOCK_FILE="/var/lock/swap_setup.lck"
LOG_FILE="/var/log/swap_setup_log.txt"
SWAP_SETUP='/share/CACHEDEV1_DATA/.qpkg/QSWAP/swap_setup.sh start'

if [ -f "$LOG_FILE" ]; then
   echo "Naplo fajl mar letezik, a folyamat megszakitva."
else
   echo "Naplo fajl letrehozasa folyamatban..."
   touch "$LOG_FILE"
   echo "Naplo fajl letrehozva."
   echo "Naplo fajl letrehozva." >> "$LOG_FILE"
fi
flashdrive() {
    df | grep -q "/share/external/DEV3302_1"
    }
if [ -f "$LOCK_FILE" ] && flashdrive; then
    echo "SWAP tarterulet mar beallitva, a folyamat megszakitva."
    exit 0
else
    echo "SWAP tarterulet beallitasa most elindul..."
    echo "SWAP tarterulet beallitasa most elindul..." >> "$LOG_FILE"
    flashdrive() {
    df | grep -q "/share/external/DEV3302_1"
    }
    if flashdrive; then
        eval "$SWAP_SETUP" >> "$LOG_FILE" 2>&1
    if [ $? -ne 0 ]; then
        echo "Hiba tortent a swap beallitasa soran!"
        echo "[$(date)] Hiba tortent a swap beallitasa soran." >> "$LOG_FILE"
        exit 1
fi
if [ -f "$LOCK_FILE" ]; then
echo "Lock fájl már létezik, a folyamat megszakitva."
else
    touch "$LOCK_FILE"
    echo "Lock fajl letrehozva."
    echo "Lock fajl letrehozva." >> "$LOG_FILE"
fi
    echo "Swapfile beallitva, hasznalatra kesz."
    echo "[$(date)] Swapfile beallitva, hasznalatra kesz." >> "$LOG_FILE"
else
    echo "A flashdrive nem elerheto, a swap beallitas sikertelen."
    echo "[$(date)] A flashdrive nem elerheto, a swap beallitas sikertelen." >> "$LOG_FILE"
    exit 1
fi
fi
  for i in {1..3}; do
    eval "$SHORT_BEEP" >> "$LOG_FILE" 2>&1
    sleep 1
  done
echo "SWAP tarterulet beallitasa lefutott."
exit 0
