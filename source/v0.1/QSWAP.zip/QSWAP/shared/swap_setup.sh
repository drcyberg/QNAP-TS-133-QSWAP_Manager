#!/bin/sh

SHORT_BEEP='/sbin/hal_app --se_buzzer enc_id=0,mode=101 - short beep'
LONG_BEEP='/sbin/hal_app --se_buzzer enc_id=0,mode=100 - long beep'
CRON_FILE="/etc/config/crontab"
CRON_LINE='*/5 * * * * sh /share/CACHEDEV1_DATA/.qpkg/QSWAP/swap_check.sh'
RESTORE_CRON_LINE="sed -i '/\*\/5 \* \* \* \* sh \/share\/CACHEDEV1_DATA\/\.qpkg\/QSWAP\/swap_check\.sh/d' /etc/config/crontab"
SWAPFILE="/share/external/DEV3302_1/swapfile"
DEFAULT_SWAPFILE="/share/CACHEDEV1_DATA/.swap/qnap_swap"
LOGFILE="/var/log/swap_setup_log.txt"
SCRIPT_TO_RUN="dd if=/dev/zero of=/share/external/DEV3302_1/swapfile bs=1024 count=8388608"
DEFAULT_SCRIPT_TO_RUN="dd if=/dev/zero of=/share/CACHEDEV1_DATA/.swap/qnap_swap bs=1024 count=16777216"
LOCK_FILE="/var/lock/swap_setup.lck"
CRONTAB_PROCESS='crontab /etc/config/crontab && /etc/init.d/crond.sh restart'

case "$1" in
  start)
    echo "SWAP tarterulet beallitasa most elindul..."
    echo "[$(date)] SWAP tarterulet beallitasa most elindul..." >> "$LOGFILE"
    flashdrive() {
    df | grep -q "/share/external/DEV3302_1"
    }
  if [ -f "$SWAPFILE" ] && flashdrive; then
    echo "Swapfile mar letezik, csere..."
    echo "[$(date)] Swapfile mar letezik, csere..." >> "$LOGFILE"
    swapoff -a
    rm -f "$SWAPFILE"
    eval "$SCRIPT_TO_RUN" >> "$LOGFILE" 2>&1
    chmod 600 "$SWAPFILE"
    mkswap "$SWAPFILE"
    swapon "$SWAPFILE"
    sysctl -w vm.swappiness=10
    sysctl -w vm.vfs_cache_pressure=50
    sysctl -w vm.dirty_ratio=10
    sysctl -w vm.dirty_background_ratio=5
    sysctl -w vm.min_free_kbytes=65536
    rm -f "$LOCK_FILE"
    rm -f "$DEFAULT_SWAPFILE"
    #cp "$CRON_FILE" "${CRON_FILE}.bak_$(date +%F_%H-%M-%S)"
    cp "$CRON_FILE" "${CRON_FILE}.bak"
  if grep -Fxq "$CRON_LINE" "$CRON_FILE"; then
    echo "A sor mar szerepel a crontabban, nem tortent modositas."
  else
    echo "$CRON_LINE" >> "$CRON_FILE"
    eval "$CRONTAB_PROCESS" >> "$LOGFILE" 2>&1
    echo "Parancssor hozzaadva a crontabhoz."
  fi
    echo "Swapfile beallitva, hasznalatra kesz."
    echo "[$(date)] Swapfile beallitva, hasznalatra kesz." >> "$LOGFILE"
  else
    echo "Swapfile nem letezik, letrehozas..."
    echo "[$(date)] Swapfile nem letezik letrehozas..." >> "$LOGFILE"
    eval "$SCRIPT_TO_RUN" >> "$LOGFILE" 2>&1
    chmod 600 "$SWAPFILE"
    swapoff -a
    mkswap "$SWAPFILE"
    swapon "$SWAPFILE"
    sysctl -w vm.swappiness=10
    sysctl -w vm.vfs_cache_pressure=50
    sysctl -w vm.dirty_ratio=10
    sysctl -w vm.dirty_background_ratio=5
    sysctl -w vm.min_free_kbytes=65536
    rm -f "$LOCK_FILE"
    rm -f "$DEFAULT_SWAPFILE"
    #cp "$CRON_FILE" "${CRON_FILE}.bak_$(date +%F_%H-%M-%S)"
    cp "$CRON_FILE" "${CRON_FILE}.bak"
  if grep -Fxq "$CRON_LINE" "$CRON_FILE"; then
    echo "A sor mar szerepel a crontabban, nem tortent modositas."
  else
    echo "$CRON_LINE" >> "$CRON_FILE"
    eval "$CRONTAB_PROCESS" >> "$LOGFILE" 2>&1
    echo "Parancssor hozzaadva a crontabhoz."
  fi
    echo "Swapfile beallitva, hasznalatra kesz."
    echo "[$(date)] Swapfile beallitva, hasznalatra kesz." >> "$LOGFILE"
  fi
  for i in {1..3}; do
    eval "$SHORT_BEEP" >> "$LOGFILE" 2>&1
    sleep 1
        done
    touch "$LOCK_FILE"
    echo "SWAP tarterulet beallitasa lefutott."
    echo "[$(date)] SWAP tarterulet beallitasa lefutott." >>"$LOGFILE"
    exit 0
    ;;
  stop)
    echo "SWAP tarterulet beallitas visszavonasa..."
    echo "[$(date)] SWAP tarterulet beallitas visszavonasa..." >>"$LOGFILE"
    swapoff -a
    rm -f "$SWAPFILE"
    rm -f "$LOCK_FILE"
  if grep -Fq "$CRON_LINE" "$CRON_FILE"; then
    eval "$RESTORE_CRON_LINE" >> "$LOGFILE" 2>&1
    eval "$CRONTAB_PROCESS" >> "$LOGFILE" 2>&1
    echo "Parancssor torolve lett a crontabbol."
  else
    echo "Parancssor nem szerepel a crontabban, nincs teendo."
  fi
  for i in {1..3}; do
    eval "$SHORT_BEEP" >> "$LOGFILE" 2>&1
    sleep 1
        done
    echo "SWAP tarterulet beallitas visszavonasa kesz."
    echo "[$(date)] SWAP tarterulet beallitas visszavonasa kesz." >>"$LOGFILE"
    exit 0
    ;;
  restart)
    $0 stop
    $0 start
    touch "$LOCK_FILE"
        for i in {1..3}; do
    eval "$SHORT_BEEP" >> "$LOGFILE" 2>&1
    sleep 1
        done
     echo "SWAP tarterulet beallitas ujrainditasa kesz."
    echo "[$(date)] SWAP tarterulet beallitas ujrainditasa kesz." >>"$LOGFILE"
    exit 0
    ;;
  restore)
  eval "$SHORT_BEEP" >> "$LOGFILE" 2>&1
  echo -n "Biztosan vegrehajtod a SWAP tartomány visszaallitasat? [y/n]: "
    while true; do
        read -r yn
        case "$yn" in
            [Yy])
                break
                ;;
            [Nn])
                echo "Muvelet megszakitva."
                eval "$LONG_BEEP" >> "$LOGFILE" 2>&1
                exit 0
                ;;
            *)
                echo -n "Kerlek, csak 'y' vagy 'n' valaszt adj meg: "
                ;;
        esac
                done
    echo "SWAP tarterulet beallitas visszavonasa..."
    echo "[$(date)] SWAP tarterulet beallitas visszavonasa..." >>"$LOGFILE"
    swapoff -a
    rm -f "$SWAPFILE"
    rm -f "$LOCK_FILE"
    eval "$DEFAULT_SCRIPT_TO_RUN" >> "$LOGFILE" 2>&1
    chmod 600 "$SWAPFILE"
    mkswap "$DEFAULT_SWAPFILE"
    swapon "$DEFAULT_SWAPFILE"
    #cp "$CRON_FILE" "${CRON_FILE}.bak_$(date +%F_%H-%M-%S)"
    cp "$CRON_FILE" "${CRON_FILE}.bak"
  if grep -Fq "$CRON_LINE" "$CRON_FILE"; then
    eval "$RESTORE_CRON_LINE" >> "$LOGFILE" 2>&1
    eval "$CRONTAB_PROCESS" >> "$LOGFILE" 2>&1
    echo "Parancssor torolve lett a crontabbol."
  else
    echo "Parancssor nem szerepel a crontabban, nincs teendo."
  fi
    for i in {1..3}; do
         eval "$SHORT_BEEP" >> "$LOGFILE" 2>&1
         sleep 1
    done
    echo "SWAP tarterulet visszaallitasa kesz."
    echo "[$(date)] SWAP tarterulet visszaallitasa kesz." >>"$LOGFILE"
    exit 0
    ;;
  *)
    eval "$SHORT_BEEP"
    echo "Usage: $0 {start|stop|restart|restore}"
    exit 1
    ;;
esac

exit 0
